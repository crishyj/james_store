<?php
$author = "kerphi";
$website = "http://www.phpfreechat.net";
?>